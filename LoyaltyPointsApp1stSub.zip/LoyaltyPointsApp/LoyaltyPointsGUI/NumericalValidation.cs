﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationLibrary_
{
    public class NumericalValidation
    { 
        //unit tested and working "PhoneNumValid"
        //potential addition to remove dash or dot chars. 
        public static bool PhoneNumVld(string x)
        {
            long y;
           
            bool canConvert = long.TryParse(x, out y);
            if (x.Length < 10 || x.Length > 10)
            {
                return false;
            }
            else if (canConvert == false)
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        //makes sure that customer has enought points to redeem. 
        public static bool EnoughPtAvailable(int x)
        {
            if (x < 300)
            {
                return false; 
            }
            else
            {
                return true; 
            }

            
        }




    }
}
