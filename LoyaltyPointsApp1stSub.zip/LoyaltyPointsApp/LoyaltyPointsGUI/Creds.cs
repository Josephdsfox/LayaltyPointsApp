﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace UserCredentialsLibrary
{
    public class Creds
    {
        private static void CheckPassword(string pw1, string pw2)
        {
            TempPassword temp = new TempPassword();
            if (pw1 == pw2)
            {
                ///////this is where we would build the quarterback method to 
                ///store all the user credentials and this mehtod should also take in the username. 
                ///save everything 
                ///salt the password and has the damn thing 
                ///save the salt and the password. 
                temp.TempPass = pw2;
            }
            else
            {
                throw new Exception();
            }
        }
        //unfinished implementaion 
        private static string ConcatSalt()
        {
            return "should be salt + temp password used to send for hashing.";
        }
        private static string GetSalt()
        {
            var random = new RNGCryptoServiceProvider();

            // Maximum length of salt
            int max_length = 32;

            // Empty salt array
            byte[] salt = new byte[max_length];

            // Build the random bytes
            random.GetNonZeroBytes(salt);

            // Return the string encoded salt
            return Convert.ToBase64String(salt);
        }
        public struct TempPassword
        {
            private string tempPass;

            public string TempPass
            {
                get { return tempPass; }
                set { tempPass = value; }
            }

        }
        private static bool Validation(string hash, string user)
        {
            string temp = ComputingHashMDS(user);
            if (hash == temp)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        // For hashing a username string into my program for credential security. 
        private static string ComputingHashMDS(string input)
        {
            //a class for building a string can update, append or remove from with method calls.
            StringBuilder stringBuilder = new StringBuilder();

            // setting the string to an encoded byte array 
            byte[] textBytes = Encoding.ASCII.GetBytes(input);

            // creates an instance of of MD5 hash algorithm. 
            using (MD5 md5 = MD5.Create())
            {                   //compute hash uses the object (byte array "textBytes") to create the hash value. 
                byte[] computeHash = md5.ComputeHash(textBytes);

                for (int i = 0; i < computeHash.Length; i++)
                {
                    //stringbuilder.append will add each hashed byte into an empty string sarting at 0 until .length 
                    //then the value is converted to type string with the .Tostring Method. 
                    stringBuilder.Append(computeHash[i].ToString());
                }
            }
            //returns the string hashed to caller. 
            return stringBuilder.ToString();
        }


    }
}
