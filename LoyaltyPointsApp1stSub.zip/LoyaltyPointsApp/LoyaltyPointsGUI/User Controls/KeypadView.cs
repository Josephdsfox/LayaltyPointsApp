﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoyaltyPointsGUI
{
    public partial class KeypadView : UserControl
    {
        public KeypadView()
        {
            InitializeComponent();
        }
      

        private void KeypadView_Load(object sender, EventArgs e)
        {

        }

        #region keypadDirections
        private void BtnKeypad_1_Click(object sender, EventArgs e)
        {
            TbPhoneNumber.Text += "1";
        }

        private void BtnKeypad_2_Click(object sender, EventArgs e)
        {
            TbPhoneNumber.Text += "2";
        }

        private void BtnKeypad_3_Click(object sender, EventArgs e)
        {
            TbPhoneNumber.Text += "3";
        }

        private void BtnKeypad_4_Click(object sender, EventArgs e)
        {
            TbPhoneNumber.Text += "4";
        }

        private void BtnKeypad_5_Click(object sender, EventArgs e)
        {
            TbPhoneNumber.Text += "5";
        }

        private void BtnKeypad_6_Click(object sender, EventArgs e)
        {
            TbPhoneNumber.Text += "6";
        }

        private void BtnKeypad_7_Click(object sender, EventArgs e)
        {
            TbPhoneNumber.Text += "7";
        }

        private void BtnKeypad_8_Click(object sender, EventArgs e)
        {
            TbPhoneNumber.Text += "8";
        }

        private void BtnKeypad_9_Click(object sender, EventArgs e)
        {
            TbPhoneNumber.Text += "9";
        }

        private void BtnKeypad_0_Click(object sender, EventArgs e)
        {
            TbPhoneNumber.Text += "0";
        }

        #endregion
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            //calls to the method that sees if there is a user with that phone number and if so launch the user view 
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            this.Hide(); 
        }

        private void BtnReadMe_Click(object sender, EventArgs e)
        {

        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            TbPhoneNumber.Clear(); 
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            string newVal = "";  
            char[] eaches = TbPhoneNumber.Text.ToCharArray(); 
            int length = TbPhoneNumber.Text.Length;
            for (int i = 0; i < length -1 ; i++)
            {
                newVal += eaches[i].ToString(); 
            }
            TbPhoneNumber.Clear();
            TbPhoneNumber.Text = newVal;

        }
    }
}
