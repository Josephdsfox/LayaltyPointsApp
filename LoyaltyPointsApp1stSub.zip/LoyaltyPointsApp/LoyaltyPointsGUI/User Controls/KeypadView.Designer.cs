﻿namespace LoyaltyPointsGUI
{
    partial class KeypadView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.BtnClear = new System.Windows.Forms.Button();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.BtnKeypad_0 = new LoyaltyPointsGUI.RoundButton();
            this.BtnKeypad_9 = new LoyaltyPointsGUI.RoundButton();
            this.BtnKeypad_8 = new LoyaltyPointsGUI.RoundButton();
            this.BtnKeypad_7 = new LoyaltyPointsGUI.RoundButton();
            this.BtnKeypad_6 = new LoyaltyPointsGUI.RoundButton();
            this.BtnKeypad_5 = new LoyaltyPointsGUI.RoundButton();
            this.BtnKeypad_4 = new LoyaltyPointsGUI.RoundButton();
            this.BtnKeypad_3 = new LoyaltyPointsGUI.RoundButton();
            this.BtnKeypad_2 = new LoyaltyPointsGUI.RoundButton();
            this.BtnKeypad_1 = new LoyaltyPointsGUI.RoundButton();
            this.BtnReadMe = new System.Windows.Forms.Button();
            this.TbPhoneNumber = new System.Windows.Forms.TextBox();
            this.BtnSearch = new System.Windows.Forms.Button();
            this.BtnLogout = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.BtnClear);
            this.panel1.Controls.Add(this.BtnDelete);
            this.panel1.Controls.Add(this.BtnKeypad_0);
            this.panel1.Controls.Add(this.BtnKeypad_9);
            this.panel1.Controls.Add(this.BtnKeypad_8);
            this.panel1.Controls.Add(this.BtnKeypad_7);
            this.panel1.Controls.Add(this.BtnKeypad_6);
            this.panel1.Controls.Add(this.BtnKeypad_5);
            this.panel1.Controls.Add(this.BtnKeypad_4);
            this.panel1.Controls.Add(this.BtnKeypad_3);
            this.panel1.Controls.Add(this.BtnKeypad_2);
            this.panel1.Controls.Add(this.BtnKeypad_1);
            this.panel1.Location = new System.Drawing.Point(274, 147);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(342, 350);
            this.panel1.TabIndex = 0;
            // 
            // BtnClear
            // 
            this.BtnClear.Location = new System.Drawing.Point(19, 295);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(75, 44);
            this.BtnClear.TabIndex = 11;
            this.BtnClear.Text = "Clear";
            this.BtnClear.UseVisualStyleBackColor = true;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.Location = new System.Drawing.Point(240, 295);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(75, 44);
            this.BtnDelete.TabIndex = 10;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // BtnKeypad_0
            // 
            this.BtnKeypad_0.BackColor = System.Drawing.Color.White;
            this.BtnKeypad_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeypad_0.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnKeypad_0.Location = new System.Drawing.Point(132, 284);
            this.BtnKeypad_0.Name = "BtnKeypad_0";
            this.BtnKeypad_0.Size = new System.Drawing.Size(69, 59);
            this.BtnKeypad_0.TabIndex = 9;
            this.BtnKeypad_0.Text = "0";
            this.BtnKeypad_0.UseVisualStyleBackColor = false;
            this.BtnKeypad_0.Click += new System.EventHandler(this.BtnKeypad_0_Click);
            // 
            // BtnKeypad_9
            // 
            this.BtnKeypad_9.BackColor = System.Drawing.Color.White;
            this.BtnKeypad_9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeypad_9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnKeypad_9.Location = new System.Drawing.Point(240, 203);
            this.BtnKeypad_9.Name = "BtnKeypad_9";
            this.BtnKeypad_9.Size = new System.Drawing.Size(69, 59);
            this.BtnKeypad_9.TabIndex = 8;
            this.BtnKeypad_9.Text = "9";
            this.BtnKeypad_9.UseVisualStyleBackColor = false;
            this.BtnKeypad_9.Click += new System.EventHandler(this.BtnKeypad_9_Click);
            // 
            // BtnKeypad_8
            // 
            this.BtnKeypad_8.BackColor = System.Drawing.Color.White;
            this.BtnKeypad_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeypad_8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnKeypad_8.Location = new System.Drawing.Point(132, 203);
            this.BtnKeypad_8.Name = "BtnKeypad_8";
            this.BtnKeypad_8.Size = new System.Drawing.Size(69, 59);
            this.BtnKeypad_8.TabIndex = 7;
            this.BtnKeypad_8.Text = "8";
            this.BtnKeypad_8.UseVisualStyleBackColor = false;
            this.BtnKeypad_8.Click += new System.EventHandler(this.BtnKeypad_8_Click);
            // 
            // BtnKeypad_7
            // 
            this.BtnKeypad_7.BackColor = System.Drawing.Color.White;
            this.BtnKeypad_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeypad_7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnKeypad_7.Location = new System.Drawing.Point(19, 203);
            this.BtnKeypad_7.Name = "BtnKeypad_7";
            this.BtnKeypad_7.Size = new System.Drawing.Size(69, 59);
            this.BtnKeypad_7.TabIndex = 6;
            this.BtnKeypad_7.Text = "7";
            this.BtnKeypad_7.UseVisualStyleBackColor = false;
            this.BtnKeypad_7.Click += new System.EventHandler(this.BtnKeypad_7_Click);
            // 
            // BtnKeypad_6
            // 
            this.BtnKeypad_6.BackColor = System.Drawing.Color.White;
            this.BtnKeypad_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeypad_6.ForeColor = System.Drawing.Color.Black;
            this.BtnKeypad_6.Location = new System.Drawing.Point(240, 109);
            this.BtnKeypad_6.Name = "BtnKeypad_6";
            this.BtnKeypad_6.Size = new System.Drawing.Size(69, 59);
            this.BtnKeypad_6.TabIndex = 5;
            this.BtnKeypad_6.Text = "6";
            this.BtnKeypad_6.UseVisualStyleBackColor = false;
            this.BtnKeypad_6.Click += new System.EventHandler(this.BtnKeypad_6_Click);
            // 
            // BtnKeypad_5
            // 
            this.BtnKeypad_5.BackColor = System.Drawing.Color.White;
            this.BtnKeypad_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeypad_5.ForeColor = System.Drawing.Color.Black;
            this.BtnKeypad_5.Location = new System.Drawing.Point(132, 109);
            this.BtnKeypad_5.Name = "BtnKeypad_5";
            this.BtnKeypad_5.Size = new System.Drawing.Size(69, 59);
            this.BtnKeypad_5.TabIndex = 4;
            this.BtnKeypad_5.Text = "5";
            this.BtnKeypad_5.UseVisualStyleBackColor = false;
            this.BtnKeypad_5.Click += new System.EventHandler(this.BtnKeypad_5_Click);
            // 
            // BtnKeypad_4
            // 
            this.BtnKeypad_4.BackColor = System.Drawing.Color.White;
            this.BtnKeypad_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeypad_4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnKeypad_4.Location = new System.Drawing.Point(19, 109);
            this.BtnKeypad_4.Name = "BtnKeypad_4";
            this.BtnKeypad_4.Size = new System.Drawing.Size(69, 59);
            this.BtnKeypad_4.TabIndex = 3;
            this.BtnKeypad_4.Text = "4";
            this.BtnKeypad_4.UseVisualStyleBackColor = false;
            this.BtnKeypad_4.Click += new System.EventHandler(this.BtnKeypad_4_Click);
            // 
            // BtnKeypad_3
            // 
            this.BtnKeypad_3.BackColor = System.Drawing.Color.White;
            this.BtnKeypad_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeypad_3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnKeypad_3.Location = new System.Drawing.Point(240, 19);
            this.BtnKeypad_3.Name = "BtnKeypad_3";
            this.BtnKeypad_3.Size = new System.Drawing.Size(69, 59);
            this.BtnKeypad_3.TabIndex = 2;
            this.BtnKeypad_3.Text = "3";
            this.BtnKeypad_3.UseVisualStyleBackColor = false;
            this.BtnKeypad_3.Click += new System.EventHandler(this.BtnKeypad_3_Click);
            // 
            // BtnKeypad_2
            // 
            this.BtnKeypad_2.BackColor = System.Drawing.Color.White;
            this.BtnKeypad_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeypad_2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnKeypad_2.Location = new System.Drawing.Point(132, 19);
            this.BtnKeypad_2.Name = "BtnKeypad_2";
            this.BtnKeypad_2.Size = new System.Drawing.Size(69, 59);
            this.BtnKeypad_2.TabIndex = 1;
            this.BtnKeypad_2.Text = "2";
            this.BtnKeypad_2.UseVisualStyleBackColor = false;
            this.BtnKeypad_2.Click += new System.EventHandler(this.BtnKeypad_2_Click);
            // 
            // BtnKeypad_1
            // 
            this.BtnKeypad_1.BackColor = System.Drawing.Color.White;
            this.BtnKeypad_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKeypad_1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnKeypad_1.Location = new System.Drawing.Point(19, 19);
            this.BtnKeypad_1.Name = "BtnKeypad_1";
            this.BtnKeypad_1.Size = new System.Drawing.Size(69, 59);
            this.BtnKeypad_1.TabIndex = 0;
            this.BtnKeypad_1.Text = "1";
            this.BtnKeypad_1.UseVisualStyleBackColor = false;
            this.BtnKeypad_1.Click += new System.EventHandler(this.BtnKeypad_1_Click);
            // 
            // BtnReadMe
            // 
            this.BtnReadMe.Location = new System.Drawing.Point(77, 540);
            this.BtnReadMe.Name = "BtnReadMe";
            this.BtnReadMe.Size = new System.Drawing.Size(112, 32);
            this.BtnReadMe.TabIndex = 1;
            this.BtnReadMe.Text = "ReadMe";
            this.BtnReadMe.UseVisualStyleBackColor = true;
            this.BtnReadMe.Click += new System.EventHandler(this.BtnReadMe_Click);
            // 
            // TbPhoneNumber
            // 
            this.TbPhoneNumber.Font = new System.Drawing.Font("Microsoft Himalaya", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbPhoneNumber.Location = new System.Drawing.Point(247, 79);
            this.TbPhoneNumber.Name = "TbPhoneNumber";
            this.TbPhoneNumber.Size = new System.Drawing.Size(394, 47);
            this.TbPhoneNumber.TabIndex = 2;
            // 
            // BtnSearch
            // 
            this.BtnSearch.BackColor = System.Drawing.Color.Black;
            this.BtnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BtnSearch.Font = new System.Drawing.Font("Microsoft Himalaya", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSearch.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnSearch.Location = new System.Drawing.Point(333, 512);
            this.BtnSearch.Name = "BtnSearch";
            this.BtnSearch.Size = new System.Drawing.Size(233, 60);
            this.BtnSearch.TabIndex = 3;
            this.BtnSearch.Text = "Search";
            this.BtnSearch.UseVisualStyleBackColor = false;
            this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // BtnLogout
            // 
            this.BtnLogout.Location = new System.Drawing.Point(710, 79);
            this.BtnLogout.Name = "BtnLogout";
            this.BtnLogout.Size = new System.Drawing.Size(108, 35);
            this.BtnLogout.TabIndex = 4;
            this.BtnLogout.Text = "Log Out";
            this.BtnLogout.UseVisualStyleBackColor = true;
            this.BtnLogout.Click += new System.EventHandler(this.BtnLogout_Click);
            // 
            // KeypadView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.BtnLogout);
            this.Controls.Add(this.BtnSearch);
            this.Controls.Add(this.TbPhoneNumber);
            this.Controls.Add(this.BtnReadMe);
            this.Controls.Add(this.panel1);
            this.Name = "KeypadView";
            this.Size = new System.Drawing.Size(891, 683);
            this.Load += new System.EventHandler(this.KeypadView_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BtnReadMe;
        private RoundButton BtnKeypad_1;
        private RoundButton BtnKeypad_0;
        private RoundButton BtnKeypad_9;
        private RoundButton BtnKeypad_8;
        private RoundButton BtnKeypad_7;
        private RoundButton BtnKeypad_6;
        private RoundButton BtnKeypad_5;
        private RoundButton BtnKeypad_4;
        private RoundButton BtnKeypad_3;
        private RoundButton BtnKeypad_2;
        private System.Windows.Forms.TextBox TbPhoneNumber;
        private System.Windows.Forms.Button BtnSearch;
        private System.Windows.Forms.Button BtnLogout;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.Button BtnDelete;
    }
}
