﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoyaltyPointsGUI
{
    public partial class LoginView : UserControl
    {
       
        public LoginView()
        {
            InitializeComponent();
        }
        



        private void BtnLogin_Click(object sender, EventArgs e)
        {
            

            try
            {
                if (TbUserName.Text == "Joe")
                {
                    KeypadView keys = new KeypadView();
                    keys.Dock = DockStyle.Fill;
                    this.Controls.Add(keys);

                    TbUserName.Clear();
                    TbPassword.Clear();
                    
                }
                else
                {
                    MessageBox.Show("That User Does Not Exist");
                    TbUserName.Clear();
                    TbPassword.Clear();
                }
             
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        private void TbUserName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
