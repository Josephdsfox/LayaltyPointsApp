﻿-----------------------------------------------------------------------------------------------------------------------------------------------------
								Loyalty Points Applicaton 
								   Creted by Joseph Fox 
									  2022
-----------------------------------------------------------------------------------------------------------------------------------------------------
Project Overview

The loyalty points application is a system for tracking customer sales transaction and awarding points base on the amount of money a customer spends.
Each point earned requires one dollar to be spent. The employee is responsible for adding and reedeeming those points. The programs entry point takes
it's user to a login window where a user name and password are required to gain access to the customer look-up window. Once logged in the user will 
enter the phone number of a guest, if the guest has a profile they will be navigated to the customer profile, if the customer does not have a profile
one ca be made form the same location by selecting "Register New Customer". A customer profile requires their first and last name, the customers 
phone number, email address, customer ID, and point balance. Once a customer profile is accessed the employee is able to add points in the equivelent 
amount as the customer spends on the current transaction. If the customer has enough avaiable points they can redeem them for a discounted price on 
goods. In the future I would like to reuse segments of the solution to actually sync to a sales portal, so that each transaction can automatically 
add the points and only require the current user to enter the redemption portal to reduce the sales final price if enough points are available. To 
redeem points for a $10 off cupon, the customer must have spent $300 prior to the transaction. Each $10 off vouncher requires 300 points with no 
limitation to the amount that can be reedeemed in a sinigle transaction ( if 1200 points exist, 4 vouchers may be redeemed for a price reduction of 
$40). The employee may log out at any point resulting in the application returning them to the login window. When the application is launched a text 
file is created on the users local hard drive. That ReadMe.txt file can be opened at any point within the application and would be removed in 
production. Their are three primary views the application navigates. 

1. Login - this consists of text boxs for the user name and password and a button to "Login" 

2. Keypad - a 10 digit keypad with a textbox that displays the entries. A user may click on the textbox and enter the number directly or push the 
buttons show on-screen to manually enter the customers phone number. This view also included "Search" and "Logout" buttons. 

3. Customer Profile - This shows the found customers personal information, as well as their available points. In addition, this window includes fatures
to add or redeem points with button push entries. 

-----------------------------------------------------------------------------------------------------------------------------------------------------
Description 

I chose to include this section as a quick navigational guide. I have set all the numbered sections listed in the "Table of Contents" to regions. 
If you open the ReadMe.txt file from the program, it should work a bit dynamically to close and open regions as required. 
Each content point directly cooresponds to the class or folder were the files are stored. This should be a 1:1 replica of the solution and I felt it 
would be helpful. 

-----------------------------------------------------------------------------------------------------------------------------------------------------
Table of Contents - See ZReadMe.cs for drop region based method details as described under "Description"
1. LoyaltyPointsGUI 
2. Property 
3. References
4. Models
5. Resources
6. User Controls
7. AddToReadMe.cs
8. Dashboard.cs
9. DataConnectionHelper.cs
10. LoyaltyPointsDatabaseDataSet.xsd
11. Program.cs
12. UserCredentialsLibrary
13. ValidationLibrary

-----------------------------------------------------------------------------------------------------------------------------------------------------
Solution 
-----------------------------------------------------------------------------------------------------------------------------------------------------
The solution begins on line 17 of Program.cs and the Main method serves as the entry point for the application. It runs three methods from the 
Application class. EnableVisualStyles, SetCompatibleTextRenderingDefault, and Run. 
line 22 on .Run instantiates a new Windows form "Dashboard". 
-----------------------------------------------------------------------------------------------------------------------------------------------------
Dashboard.cs is the code behind for the Dashboard form. Dashboard is a derivitive class that inherits from System.Windows.Forms.Form. Dashboard.cs is 
part of the LoyaltyPointsGUI namesapce. 
The constructor for Dashboard on line 20 runs the method InitializeCommponent, this method loads Window or Control it relays information down the line 
to LoadComponent() and loads the XAML file and creates an instance of the object. 

Line 27 loginView_Load was auto generated and currently does nothing. 

Line 32 Dashboard_Load was auto generated and currently does nothing. 

Line 39 BtnReadMe_Click is intended to creade a local file and write the contents of the ReadMe.txt file to it. 

CURRENTLY 
this method fires an event to open a message box with a yes and no 
choice 1 is to open the ReadMe file 







-----------------------------------------------------------------------------------------------------------------------------------------------------