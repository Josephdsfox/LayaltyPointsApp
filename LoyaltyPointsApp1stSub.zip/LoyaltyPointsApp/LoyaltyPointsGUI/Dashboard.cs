﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoyaltyPointsGUI
{
    
    public partial class Dashboard : Form
    {
        LoginView log = new LoginView();
        KeypadView keys = new KeypadView();
        public Dashboard()
        {
            InitializeComponent();
            //OpenLogin(); 
        }


        private void loginView1_Load(object sender, EventArgs e)
        {

        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

       

        private void BtnReadMe_Click(object sender, EventArgs e)
        {
            //TO DO: 
            // when button is clicked this should check for a file and create one if one does not exist.
            //Since the file exists in your program can I copy this to the new file location. 
            //Then read it and write it from the new From - AddToReadMe.cs (rename that too. its a bad name) 



            string path = @"C:\Documents\ReadMeCopy.txt";
            string message = "Would you like to open ReadMe.txt";
            string title = "Read File";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);
            if (result == DialogResult.Yes)
            {
                //will create a file and open a text file and add the text from read me to that file. 

            }
            else
            {
                message = "Would you like to add additional notes to ReadMe.txt?";
                title = "Write File";
                result = MessageBox.Show(message, title, buttons);

                if (result == DialogResult.Yes)
                {
                    AddToReadMe addToReadMe = new AddToReadMe();
                    addToReadMe.Show();
                }
                
            }
            
        }

        public void OpenLogin()
        {
            log.Dock = DockStyle.Fill;
            this.Controls.Add(log);
            this.Controls.Remove(keys);
            keys.Hide();
        }

        //public void OpenKeypad()
        //{
        //    keys.Dock = DockStyle.Fill;
        //    this.Controls.Add(keys);
        //    this.Controls.Remove(log);
        //    log.Hide();
        //}

        public void OpenAddCustomer()
        {
            throw new NotImplementedException();
        }
    }
}
