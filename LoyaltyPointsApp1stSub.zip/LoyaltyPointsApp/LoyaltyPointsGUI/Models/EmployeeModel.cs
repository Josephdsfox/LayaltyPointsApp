﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoxLoyaltyUI.Models
{
    
    public class EmployeeModel : UserModel
    {
        public int EmpId { get; set; }

        //what order should members be listed ? 
        public EmployeeModel()
        {

        }

        public override void CreateCustomer()
        {
            throw new NotImplementedException();
        }

        public void AddPoints()
        {

        }

        public void RedeemPoints()
        {

        }
    }
}
