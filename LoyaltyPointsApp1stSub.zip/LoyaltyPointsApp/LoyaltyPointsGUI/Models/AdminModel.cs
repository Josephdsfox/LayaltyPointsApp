﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoxLoyaltyUI.Models
{
    public class AdminModel : UserModel
    {
        public void EditCustomer()
        {

        }
        public void DeleteCustomer()
        {

        }

        public static void SelectRandCustomer()
        {

        }

        //implementation of createcustomer from UserModel 
        public override void CreateCustomer()
        {
            throw new NotImplementedException();
        }
    }
}
