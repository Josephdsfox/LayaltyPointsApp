﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading.Tasks;

namespace LoyaltyPointsGUI
{
    public sealed class DataConnectionHelper
    {
            public static string ConnVal(string name)
            {
            // return ConfigurationManager.ConnectionStrings[name].ConnectionString;
            //review and solve why ConfigurationManager is not accessable ?
            return "x";
            }
        
    }
}
